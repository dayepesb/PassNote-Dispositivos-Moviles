package passnote.poli.edu.co.PassNote;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PassNoteApplication {

	public static void main(String[] args) {
		SpringApplication.run(PassNoteApplication.class, args);
	}
}
