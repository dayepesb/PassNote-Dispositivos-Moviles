package passnote.poli.edu.co.PassNote.entities;

public class UserEntity {

}
