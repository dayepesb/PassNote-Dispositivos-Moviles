package passnote.poli.edu.co.PassNote.repository;

public class UserRepository {

}
