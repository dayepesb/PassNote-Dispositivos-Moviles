package passnote.poli.edu.co.PassNote.service.dto;

public class UserDTO {

}
